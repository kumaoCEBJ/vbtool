﻿

window.interop = {
    preventDefault: function (event) {
        event.preventDefault();
    }
};

